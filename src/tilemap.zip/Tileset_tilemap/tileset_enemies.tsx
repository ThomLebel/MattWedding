<?xml version="1.0" encoding="UTF-8"?>
<tileset name="enemies" tilewidth="128" tileheight="128" tilecount="128" columns="4">
 <image source="../tilemap_enemies.png" width="512" height="1920"/>
</tileset>
