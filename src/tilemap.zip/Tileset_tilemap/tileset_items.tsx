<?xml version="1.0" encoding="UTF-8"?>
<tileset name="items" tilewidth="128" tileheight="128" tilecount="32" columns="8">
 <image source="../Kenney_paltformer_redux/Spritesheets/spritesheet_items.png" width="1024" height="512"/>
</tileset>
