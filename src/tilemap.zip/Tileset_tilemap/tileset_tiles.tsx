<?xml version="1.0" encoding="UTF-8"?>
<tileset name="tiles" tilewidth="128" tileheight="128" tilecount="128" columns="8">
 <image source="../Kenney_paltformer_redux/Spritesheets/spritesheet_tiles.png" width="1024" height="2048"/>
</tileset>
